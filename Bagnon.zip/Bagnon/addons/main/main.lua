--[[
	main.lua
		Constant specifics for the addon
--]]

local ADDON, Addon = ...
Addon.FrameTemplate = BackdropTemplateMixin and 'BackdropTemplate'
Addon.Slash = 'bgn'
